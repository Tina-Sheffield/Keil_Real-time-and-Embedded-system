/*----------------------------------------------------------------------------
 * This is the header file for my_headers.c, please refer to the my_headers.c 
 * file for the details of the following functions and external variables. 
 *
 *   Last Modification:  13/12/2018
 *----------------------------------------------------------------------------*/


#include "stm32f4xx.h"				// The header file for stm32f407
	
void Initialise_LED_button_Timer(void); 	// Declaration for function to initialise the LEDs, button and timer

void Initialise_SPI_Interrupt_NVIC(void); 	// Declaration for function to to initialise SPI communication, interrupt and NVIC
	
extern int8_t Read_tilt(uint8_t); 	// Declaration for the function to read the tilt information from accelerometer

void EXTI0_IRQHandler(void);		// Declaration for the function of interrupt request handler for external interrupt from GPIO pin 0
	
void Tilt_LED(uint8_t,uint8_t); 	// Declaration for the function to switch the state of the LEDs when tilt the board; it has two inputs: one for the state and one for the LED's colour

extern int8_t button_clicked(int8_t button_clk);		// Declaration for the function to determine whether the blue push button is clicked

void Blink_LED(uint8_t); 	// Declaration for the function to blink the four LEDs on or off upon request

extern int8_t button_clk; 	// Define a variable that indicates weather the push button has been clicked - 0 is not clicked, 1 is clicked, and 2 is being pressed

extern int8_t x;  // Define a variable to keep the received reading of x-axis of the accelerometer, this variable is used throught this file

extern int8_t y;  // Define a variable to keep the received reading of x-axis of the accelerometer, this variable is used throught this file

extern int8_t Reg_H;  // Declare the variable to store the most significant 8-bits transmitted from the LIS3DSH register
	
