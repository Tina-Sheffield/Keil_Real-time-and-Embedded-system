/*----------------------------------------------------------------------------
 * This file contains the self-defined functions to initialse the peripherals, 
 * determine whether the push button has been clicked, reading the tilt angles
 * of the board from accelerometer and switch the LEDs on and off.
 *
 *   Last Modification:  13/12/2018
 *----------------------------------------------------------------------------*/


#include "stm32f4xx.h"			// The header file for stm32f407

// Declaration of structure handles and variables
	GPIO_InitTypeDef GPIOA_Params; 	// Declare the structure handle which defines and contains the parameters of GPIOA
  GPIO_InitTypeDef GPIOE_Params; 	// Declare the structure handle which defines and contains the parameters of GPIOE
	SPI_HandleTypeDef SPI_Params; 	// Declare the structure handle which defines and contains the parameters of SPI1
	GPIO_InitTypeDef LIS3DSH_Itrpt;   // Declare the structure handle which defines and contains the parameters of accelerometer interrupt
	uint8_t data_to_send[1];   // Declare a variable (an array) to store the required register address from LIS3DSH
	uint16_t data_size=1; 	// Declare a variable which make sure that only one address is accessed in every data transaction
  uint32_t data_timeout=1000; 	//Set variale that defines the maximum time to wait for the SPI transaction to complete
	int8_t button_clk = 0; //	Define a variable that indicates weather the push button has been clicked - 0 is not clicked, 1 is clicked, and 2 is being pressed
	int8_t x;  // Define a variable to keep the received reading of x-axis of the accelerometer, this variable is used throught this file
	int8_t y;  // Define a variable to keep the received reading of x-axis of the accelerometer, this variable is used throught this file
	uint8_t x_address = 0x29;  // Define a variable for the address of x-axis output register from the accelerometer
	uint8_t y_address = 0x2B;  // Define a variable for the address of y-axis output register from the accelerometer


// Code to define the function to initialise the LEDs, button and timer
void Initialise_LED_button_Timer(void){
 
	// Initialise GPIO Port for the LEDs
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN; // Enable the peripheral clock for GPIO Port D
	GPIOD->MODER |= GPIO_MODER_MODER12_0; // Pin 12 of GPIO Port D - green LED
	GPIOD->MODER |= GPIO_MODER_MODER13_0; // Pin 13 of GPIO Port D - orange LED
	GPIOD->MODER |= GPIO_MODER_MODER14_0; // Pin 14 of GPIO Port D - red LED
	GPIOD->MODER |= GPIO_MODER_MODER15_0; // Pin 15 of GPIO Port D - blue LED
	
	// Initialise GPIO Port for the blue user push button
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN; // Enable the peripheral clock for GPIO Port A	

	// Initialise Timer 2
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN; // Enable the peripheral clock for Timer 2
	TIM2->CR1 &= ~0x00000016; // Configure the counter of Timer 2 as an upward counter
	TIM2->CR1 &= ~0x00000008; // Turn on the repeat function for Timer 2
	TIM2->PSC = 8400-1; // Configure the prescaler value of Timer 2
	TIM2->ARR = 10000-1; // Configure the value in the auto-reload register to give a 1 second delay
	TIM2->EGR = 1; // Re-initialise Timer 2
	
	// Initialise Timer 5
	RCC->APB1ENR |= RCC_APB1ENR_TIM5EN; // Enable the peripheral clock for Timer 5
	TIM5->CR1 &= ~0x00000016; // Configure the counter of Timer 5 as an upward counter
	TIM5->CR1 &= ~0x00000008; // Turn on the repeat function for Timer 5
	TIM5->PSC = 8400-1; // Configure the prescaler value of Timer 5
	TIM5->ARR = 199-1; // Configure the value in the auto-reload register to give a 0.02 second delay
	TIM5->EGR = 1; // Re-initialise Timer 5
	
}



// Code to define the function to initialise SPI communication, interrupt and NVIC
void Initialise_SPI_Interrupt_NVIC(void){
	
	// Code to initialise the SPI
	RCC->APB2ENR |= RCC_APB2ENR_SPI1EN; 		//Enable the clock for SPI1
	
	SPI_Params.Instance = SPI1; 		// Choose SPI1 interface for the communication between GPIO and the accelerometer
	SPI_Params.Init.Mode = SPI_MODE_MASTER; 		// Configure the STM32F407 to act as the master
	SPI_Params.Init.NSS = SPI_NSS_SOFT; 		// Configure the option that software will control the slave
	SPI_Params.Init.Direction = SPI_DIRECTION_2LINES; 		// Choose full-duplex for the SPI
	SPI_Params.Init.DataSize = SPI_DATASIZE_8BIT; 		// Choose 8-bit as the data packet size
	SPI_Params.Init.CLKPolarity = SPI_POLARITY_HIGH; 		// Choose "high" as the idle polarity for the clock line
	SPI_Params.Init.CLKPhase = SPI_PHASE_2EDGE; 		// Choose where the data line will be sampled - on the second transition of the clock line
	SPI_Params.Init.FirstBit = SPI_FIRSTBIT_MSB; 		// Configure the transmission to the most significant bit first
	SPI_Params.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32; 		// Set the clock prescaler to divide the main APB2 clock (previously set to 84MHz) by 32 to give a SPI clock of 2.625MHz, which is less the maximum value of 10MHz for the SPI.
	HAL_SPI_Init(&SPI_Params); 		// Configure the SPI using the specified parameters
	
	// Code to initialise pins 5-7 of GPIO port A for the communication between GPIO and the accelerometer
	GPIOA_Params.Pin = GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7; 		// Choose pins 5, 6 and 7 for GPIOA_Params handle parameter
	GPIOA_Params.Alternate = GPIO_AF5_SPI1; 		// Choose to use alternate function 5 which is related to SPI1
	GPIOA_Params.Mode = GPIO_MODE_AF_PP; 		// Choose push-pull mode for the alternate function
	GPIOA_Params.Speed = GPIO_SPEED_FAST; 		// Choose the speed to fast
	GPIOA_Params.Pull = GPIO_NOPULL; 		// Choose no pull-up or pull-down activation
	HAL_GPIO_Init(GPIOA, &GPIOA_Params); 		// Set GPIO port A into the modes defined in GPIOA_Params handle parameter

	// Code to initialise pin 3 of GPIOE
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOEEN; 		// Enable the peripheral clock for GPIO port E
	GPIOE_Params.Pin = GPIO_PIN_3; 		// Choose pin 3 for the communication
	GPIOE_Params.Mode = GPIO_MODE_OUTPUT_PP; 		// Choose normal push-pull mode
	GPIOE_Params.Speed = GPIO_SPEED_FAST; 		// Choose the speed to fast
	GPIOE_Params.Pull = GPIO_PULLUP; 		// Choose pull-up activation
	HAL_GPIO_Init(GPIOE, &GPIOE_Params); 		// Set GPIO port A into the modes defined in GPIOA_Params handle parameter
	GPIOE->BSRR |= GPIO_PIN_3; 		// Configure the serial port to enable pin CS high, which is idle
	
	__HAL_SPI_ENABLE(&SPI_Params); 		// Enable the SPI to allow for communication
	
	// Code to enable read and write to control register 4 of the LIS3DSH to enable reading the data of x_axis and y-axis of the accelerometer
	data_to_send[0] = 0x20; 	// Choose the address for control register 4 on LIS3DSH
	GPIOE->BSRR = GPIO_PIN_3<<16; 	// Configure the SPI communication enable line to low so as to initiate communication
	HAL_SPI_Transmit(&SPI_Params,data_to_send,data_size,data_timeout); 	// Send the address of the register to be read on the LIS3DSH	
	data_to_send[0] = 0x13; 	// Set register value to give a sample rate of 3.125Hz, continuous update, x-axis enabled and y-axis enabled.
	HAL_SPI_Transmit(&SPI_Params, data_to_send,data_size, data_timeout); 	// Transmit the new value from register of LIS3DSH through the SPI channel	
	GPIOE->BSRR = GPIO_PIN_3; 	// Configure the SPI communication enable line to high so as to indicate the end of the communication process

	
	// Code to initialise GPIOE pin 0 for the external interrupt
	LIS3DSH_Itrpt.Pin = GPIO_PIN_0; 		// Choose pin 0 for the interrupt
	LIS3DSH_Itrpt.Mode = GPIO_MODE_IT_RISING; 		// Choose the interrupt to be signalled when on a rising edge
	LIS3DSH_Itrpt.Speed = GPIO_SPEED_FAST; 		// Choose Choose the speed to fast
	HAL_GPIO_Init(GPIOE, &LIS3DSH_Itrpt); 		// Configure GPIO port E into the modes specified in GPIOE_Params_Itrpt handle parameter
	
	// Code to enable read and write to control register 3 of the LIS3DSH to set up the interrupts
	data_to_send[0] = 0x23; 	// Choose the address for control register 3 on LIS3DSH
	GPIOE->BSRR = GPIO_PIN_3<<16; 	// Configure the SPI communication enable line to low so as to initiate communication
	HAL_SPI_Transmit(&SPI_Params,data_to_send,data_size,data_timeout); 	// Send the address of the register to be read on the LIS3DSH	
	data_to_send[0] = 0xC8; 	// Enable DRDY connected to Int1, sets Int1 active to high, enables int1
	HAL_SPI_Transmit(&SPI_Params, data_to_send,data_size, data_timeout); 	// Transmit the new value from register of LIS3DSH through the SPI channel	
	GPIOE->BSRR = GPIO_PIN_3; 	// Configure the SPI communication enable line to high so as to indicate the end of the communication process
	

  // Code to initialise NVIC to handle the priority of the interrupt request from pin 0 of the GPIO
	HAL_NVIC_SetPriority(EXTI0_IRQn,0,1);			// Set the pre-emption priority of the interrupt request as 0 and the subpriority level as 1.
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);			// Enable the interrupt request line
	
}



// Code to define the function to read the tilt angles from x-axis and y-axis output register
int8_t Read_tilt(uint8_t Address){
		
  int8_t Reg_H; 	// Declare the variable to store the most significant 8-bits transmitted from the LIS3DSH register
	
	// Read and store the values from the MSB (high) x-axis and y-axis data register of the LIS3DSH.
	data_to_send[0] = 0x80|Address; 	// Address for the MSB x-axis (H) data register on the LIS3DSH
	GPIOE->BSRR = GPIO_PIN_3<<16; 	// Set the SPI communication enable line low to initiate communication
	HAL_SPI_Transmit(&SPI_Params,data_to_send,data_size,data_timeout); 	// Send the address of the register to be read on the LIS3DSH	
	data_to_send[0] = 0x00; 	// Set a blank address because we are waiting to receive data
	HAL_SPI_Receive(&SPI_Params,data_to_send,data_size,data_timeout); 	// Get the data from the LIS3DSH through the SPI channel
	GPIOE->BSRR = GPIO_PIN_3; 	// Set the SPI communication enable line high to signal the end of the communication process
	Reg_H = *SPI_Params.pRxBuffPtr; 	// Store the data from the SPI buffer sub-structure into variable Reg_H
		
	return Reg_H;		// Return the value of the tilt angle stored in the variable Reg_H
	
}



// Define the function of interrupt request handler for external interrupt from GPIO pin 0
void EXTI0_IRQHandler(void){
  if (__HAL_GPIO_EXTI_GET_IT(GPIO_PIN_0)==SET){ // Check the interrupt line from GPIO pin 0 and see whether it has been set			
		__HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_0); // Eliminate the interrupt before service the interrupt

		x = Read_tilt(x_address);  // Read the tilt data of x-axis and store the data in variable x
		y = Read_tilt(y_address);  // Read the tilt data of y-axis and store the data in variable y
	}
	
	HAL_NVIC_ClearPendingIRQ(EXTI0_IRQn);  // Clear pending interrupt request from GPIO pin 0
}



// Definition for the function to switch the state of the LEDs when tilt the board; it has two inputs: one for the state and one for the LED's colour
void Tilt_LED(uint8_t LED_state, uint8_t LED_colour){
	
	if(LED_state == 1){ 	// Check to see if the request is turn the LED on or off
		GPIOD->BSRR = 1<< LED_colour; 	// Assign bit to BSRR to turn on the specified LED
	}
	else{
		GPIOD->BSRR = 1<<(LED_colour +16); 	// Assign bit to BSRR to turn off the specified LED
	}
			
}


// Define the function to determine whether the push button has been clicked
int8_t button_clicked(int8_t button_clk){
	
	if((GPIOA->IDR & 0x00000001) == 0x00000001){  // Determine from GPIOA IDR register that whether the push button has been pressed
		
		// Apply a short delay of 0.02 second to avoid accidental press of the button
		TIM5->CR1 |= 1;   // Enable the counter for Timer 5
		while((TIM5->SR&0x0001)!=1){};    // Implement a 1 second delay using Timer 5
		TIM5->SR &= ~1; // Reset the flag for Timer 5
			
		if((GPIOA->IDR & 0x00000001) == 0x00000001){  // Determine from GPIOA IDR register that whether the push button has been pressed
			button_clk = 2;  // assign variable click to 2 - button being pressed
		}
	}
	
	if (button_clk == 2) {  // If the button is currently being pressed
		if ((GPIOA->IDR & 0x00000001) != 0x00000001){  // Determine if the push button is not pressed
			
			// Apply a short delay of 0.02 second to avoid accidental press of the button
			TIM5->CR1 |= 1;   // Enable the counter for Timer 5
			while((TIM5->SR&0x0001)!=1){};    // Implement a 1 second delay using Timer 5
			TIM5->SR &= ~1; // Reset the flag for Timer 5
			
			if ((GPIOA->IDR & 0x00000001) != 0x00000001){  // determine if the push button is not pressed
				button_clk = 1;  // Assign variable click to 1 - button clicked
			}
			else if ((GPIOA->IDR & 0x00000001) == 0x00000001){  // Determine from GPIOA IDR register that whether the push button has been pressed
				button_clk = 2;  // Assign variable click to 2 - button being pressed
			}
		}
	}
	
	return button_clk;  // Retrun the value of the variable to indicate the button status
}



// Definition for the function to blink the four LEDs on or off upon request
void Blink_LED(uint8_t LED_state){
	
	if(LED_state == 1){ 	// Check to see if the request is turn the LED on or off
		GPIOD->BSRR = 1<< 12; 	// Assign bit to BSRR to turn on the green LED
		GPIOD->BSRR = 1<< 13; 	// Assign bit to BSRR to turn on the orange LED
		GPIOD->BSRR = 1<< 14; 	// Assign bit to BSRR to turn on the red LED
		GPIOD->BSRR = 1<< 15; 	// Assign bit to BSRR to turn on the blue LED
	}
	
	else{
		GPIOD->BSRR = 1<< 28; 	// Assign bit to BSRR to turn off the green LED
		GPIOD->BSRR = 1<< 29; 	// Assign bit to BSRR to turn off the orange LED
		GPIOD->BSRR = 1<< 30; 	// Assign bit to BSRR to turn off the red LED
		GPIOD->BSRR = 0x80000000; 	// Assign bit to BSRR to turn off the blue LED
	}
	
}





