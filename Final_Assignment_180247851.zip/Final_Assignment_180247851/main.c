/*----------------------------------------------------------------------------
 * This is the 'main' function for the Stm32f407 tilt switch using CMSIS-RTOS.
 *
 *   Last Modification:  13/12/2018
 *---------------------------------------------------------------------------*/


#define osObjectsPublic			// define objects in main module
#include "osObjects.h"			// RTOS object definitions
#include "stm32f4xx.h"			// The header file for stm32f407
#include "my_headers.h"			// The header file defined by user
#include "Thread.h"					// The header file defined in thread


// The main function - When you tilt the board from a flat horizontal orientation downwards, the LED at the corresponding direction will turn on to show the tilt orientation
int main (void){
  osKernelInitialize ();		// initialize CMSIS-RTOS

  // Initialise peripherals below

	Initialise_LED_button_Timer();		// Function to initialise the LEDs, button and timer
	Initialise_SPI_Interrupt_NVIC();		// Function to initialise SPI communication, interrupt and NVIC
		
  // Create 'thread' functions so as to start executing
	Init_Tilt_LED_Thread (); 	// Function which specify the operation of the tilt board indicated by LEDs 
	Init_Button_Click_Thread (); 	// Function which specify the operation of blinking LEDs after clicking the push button and the operation of the board changing after a further more clicking.
	
  osKernelStart ();		// start running the threads

	while(1){}; 	// While loop so the program continues
		
}

