/*----------------------------------------------------------------------------
 * This is the header file for Thread.c, please refer to the Thread.c file for 
 * the details of the following functions. 
 *
 *   Last Modification:  13/12/2018
 *----------------------------------------------------------------------------*/

extern int Init_Tilt_LED_Thread (void);   // Declaration to initialise the main thread function that the specific LED will turn on when you tilt the board towards that LED

void Tilt_LED_Thread (void const *argument);   // Declare the function which specify the operation of the tilt board indicated by LEDs 

extern int Init_Button_Click_Thread (void);   // Declaration to initialise the main thread function that four LEDs blink every one second after clicking the push button and the state of the board changing after a further more clicking.

void Button_Click_Thread (void const *argument);   // Declare the function which specify the operation of blinking LEDs after clicking the push button and the operation of the board changing after a further more clicking.


