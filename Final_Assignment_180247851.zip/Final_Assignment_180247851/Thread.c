/*----------------------------------------------------------------------------
 * This file contains the self-defined functions to initialse the threads for  
 * the CMSIS-RTOS. There are two threads defined in this file - one is the tilt
 * LED thread which turn on one or more specific LEDs to show the tilt direction
 * of the borad, the other thread is to blick the four LEDs on and off to show
 * the tilt swith is halted.
 *
 *   Last Modification:  13/12/2018
 *----------------------------------------------------------------------------*/


#include "cmsis_os.h"      	// The header file for CMSIS RTOS 
#include "stm32f4xx.h"      // The header file for stm32f407
#include "my_headers.h"     // The header file defined by user 


// Declare the Threads
void Tilt_LED_Thread (void const *argument); // Declaration for the main thread function that the specific LED will turn on when you tilt the board towards that LED
osThreadId tid_Tilt_LED_Thread; // ID declaration for the thread, which will refer to the thread easily when we use some of the OS functions
osThreadDef (Tilt_LED_Thread, osPriorityNormal, 1, 0); // Define the main object of the thread to use later. These settings can be used to adjust specific properties, such as the priority to be normal and number of existing instances to be one

void Button_Click_Thread (void const *argument); // Declaration to initialise the main thread function that four LEDs blink every one second after clicking the push button and the state of the board changing after a further more clicking.
osThreadId tid_Button_Click_Thread; // ID declaration for the thread, which will refer to the thread easily when we use some of the OS functions
osThreadDef (Button_Click_Thread, osPriorityNormal, 1, 0); // Define the main object of the thread to use later. These settings can be used to adjust specific properties, such as the priority to be normal and number of existing instances to be one

// Declare Variables 
int8_t thread_state = 1;  // Define a variable that indicates which thread should run - 1 is for the tilt LEDs thread to run, and 2 is for the push button halt thread to run


		
/*----------------------------------------------------------------------------
 *  The thread for the tilt LEDs
 *---------------------------------------------------------------------------*/
// Initialise the main thread by defining the thread function, which will be called in the main.c file
int Init_Tilt_LED_Thread (void) {
	tid_Tilt_LED_Thread = osThreadCreate (osThread(Tilt_LED_Thread), NULL); // Create the main tilt LEDs thread object declared above and assigns it the afore declared thread ID.
	if(!tid_Tilt_LED_Thread) return(-1); // Check the tilt LEDs thread has been created correctly
	return(0);
	}

// Define the operation of the tilt board LEDs thread 
void Tilt_LED_Thread (void const *argument) {
	
	uint8_t LED_on = 1;   // Define a parameter for LED to turn on
	uint8_t LED_off = 0;   // Define a parameter for LED to turn off
	uint8_t green_LED = 12;  	// Define a parameter for green LED (GPIOD pin 12)
	uint8_t orange_LED = 13;  	// Define a parameter for orange LED (GPIOD pin 13)
	uint8_t red_LED = 14;  	// Define a parameter for red LED (GPIOD pin 14)
	uint8_t blue_LED = 15;  	// Define a parameter for blue LED (GPIOD pin 15)
	
	osSignalSet(tid_Tilt_LED_Thread,0x01);  	// Send a set signal to the tilt LEDs thread so that it starts to run at the next signal wait function

	while (1) {   	// Create an infinite loop so that the tilt board LEDs thread never terminates
		
		osSignalWait(0x01,osWaitForever);  	// Wait the set signal for the flag 0x01 of the tilt board LED thread
		osSignalClear(tid_Button_Click_Thread,0x01);   // Send a clear signal to the push button halt thread so that it will wait
		
		if (thread_state == 1) {     // Run the following code when the variable thread_state is assigned to 1
			
			// Code to determine which LED to turn on when the board is tilt down towards a certain direction, a small deadzone (aournd 5.36 degrees) is applied to each LED.
			if (x < -5) Tilt_LED(LED_on, green_LED); 	// If the receive value is smaller than a small negative value, turn on the green LED
			else Tilt_LED(LED_off, green_LED);  	// Otherwise turn off the green LED
			if (x > 5) Tilt_LED(LED_on, red_LED); 	// If the receive value is larger than a small positive value, turn on the red LED
			else Tilt_LED(LED_off, red_LED);  	// Otherwise turn off the red LED
			if (y < -5) Tilt_LED(LED_on, blue_LED); 	// If the receive value is smaller than a small negative value, turn on the blue LED
			else Tilt_LED(LED_off, blue_LED );  	// Otherwise turn off the blue LED
			if (y > 5) Tilt_LED(LED_on, orange_LED); 	// If the receive value is larger than a small positive value, turn on the orange LED
			else Tilt_LED(LED_off, orange_LED);  	// Otherwise turn off the orange LED
		
	
			// The following chunk of code determines whether the push button is clicked and halt the tilt switch
			button_clk = button_clicked(button_clk);    // Determine the status of the push button and store it in variable button_clk
			if (button_clk == 1){    // If the push button is clicked
				button_clk = 0;    // Reset the status of the push button
				thread_state = 2;   // Assign the variable thread_state to 2 so that the contents in the push button halt thread will run
				osSignalSet(tid_Button_Click_Thread,0x01);   // Send the set signal to the push button halt thread so that the push button halt thread starts to run at the next signal wait function
			}
				
			// Double check the variable thread_state as an extra insurance for the switch of threads
			if (thread_state == 2) {     	// Run the following line when the variable thread_state is assigned to 2
				osSignalSet(tid_Button_Click_Thread,0x01);   // Send the signal to the tilt LEDs thread so that this thread continues to run at the next signal wait function	
			}
			else if (thread_state == 1) {			// Run the following line when the variable thread_state is assigned to 1
				osSignalSet(tid_Tilt_LED_Thread,0x01);   // Send the set signal to the button click thread so that the push button halt thread starts to run at the next signal wait function
			}
		
		}
		
		osThreadYield();    // Ask the RTOS to reschedule and run the next ready-to-run thread
	}	    // The end of the "while (1)" loop in the tilt board LEDs thread

}



/*----------------------------------------------------------------------------
 *  The thread for the push button which halt the tilt switch
 *---------------------------------------------------------------------------*/
// Code to define the thread function to initialise the main thread - this initialise function is called from the "main.c" file to start the thread.
int Init_Button_Click_Thread (void) {
	tid_Button_Click_Thread = osThreadCreate (osThread(Button_Click_Thread), NULL); // Create the main push button halt thread object declared above and assign it the afore declared thread ID.
	if(!tid_Button_Click_Thread) return(-1);   // Check the push button halt thread has been created correctly
	return(0);
	}

// Define the operation of the push button halt thread 
void Button_Click_Thread (void const *argument) {
	
	uint8_t LED_on = 1;   // Define parameter for LED on
	uint8_t LED_off = 0;   // Define parameter for LED off
		
	osSignalClear(tid_Button_Click_Thread,0x01);   // Send a clear signal to the tilt board LEDs thread so that it starts to run at the next signal wait function
	
	while (1) {     // Create an infinite loop so that the push button halt thread never terminates
	
		osSignalWait(0x01,osWaitForever);    // Wait the set signal for the flag 0x01 of the push button halt thread
		osSignalClear(tid_Tilt_LED_Thread,0x01);   // Send the clear signal to the tilt board LEDs thread so that it will wait
		
		// Code to turn on the four LEDs for 1 second
		if (thread_state == 2) {			// Run the following code when the variable thread_state is assigned to 2
			Blink_LED(LED_on);   // Turn on the four LEDs
			TIM2->SR &= ~1; // Reset the flag for Timer 2
			TIM2->CR1 |= 1;   // Enable the counter for Timer 2
			while((TIM2->SR&0x0001)!=1){    // Implement a 1 second delay using Timer 2
				button_clk = button_clicked(button_clk);    // Determine the status of the push button and store it in variable button_clk
				if (button_clk == 1){      // If the push button is clicked
					button_clk = 0;    // Reset the status of the push button
					thread_state = 1;   // Assign the variable thread_state to 1 so that the contents in the tile borad LEDs thread will run
					osSignalSet(tid_Tilt_LED_Thread,0x01);   // Send the set signal to the push button halt thread so that the push button halt thread starts to run at the next signal wait function
				}
			}
		}
		
		// Code to turn off the four LEDs for 1 second
		if (thread_state == 2) {     	// Run the following code when the variable thread_state is assigned to 2
			Blink_LED(LED_off);  // Turn off the four LEDs
			TIM2->SR &= ~1; // Reset the flag for Timer 2
			TIM2->CR1 |= 1;   // Enable the counter for Timer 2
			while((TIM2->SR&0x0001)!=1){    // Implement a 1 second delay using Timer 2
				button_clk = button_clicked(button_clk);    // Determine the status of the push button and store it in variable button_clk
				if (button_clk == 1){      // If the push button is clicked
					button_clk = 0;    // Reset the status of the push button
					thread_state = 1;   // Assign the variable thread_state to 1 so that the contents in the tile borad LEDs thread will run
					osSignalSet(tid_Tilt_LED_Thread,0x01);   // Send the set signal to the push button halt thread so that the push button halt thread starts to run at the next signal wait function
				}		
			}
		}
		
		// Double check the variable thread_state as an extra insurance for the switch of threads
		if (thread_state == 2) {     	// Run the following line when the variable thread_state is assigned to 2
			osSignalSet(tid_Button_Click_Thread,0x01);   // Send the signal to the tilt board LEDs thread so that this thread continues to run at the next signal wait function	
		}
		else if (thread_state == 1) {			// Run the following line when the variable thread_state is assigned to 1
			osSignalSet(tid_Tilt_LED_Thread,0x01);   // Send the set signal to the push button halt thread so that the push button halt thread starts to run at the next signal wait function
		}		
			
		osThreadYield();    // Ask the RTOS to reschedule and run the next ready-to-run thread
	}	    // The end of the "while (1)" loop in the push button halt thread
				
}

